#!/usr/bin/env python3.5

from django.contrib import admin
from django.contrib.admin import AdminSite

from .models import Figure
from .models import Animation

# limited access
